# SCC-V.2
Calcular la capacidad de maquina vs la demanda
